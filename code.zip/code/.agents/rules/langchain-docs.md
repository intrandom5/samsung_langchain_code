---
trigger: always_on
---

LangChain 관련 코드는 반드시 아래 문서를 확인하고 최신 버전으로 작성할 것.

https://docs.langchain.com/oss/python/langchain/overview.md