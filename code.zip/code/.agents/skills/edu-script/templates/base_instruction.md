# 스크립트 실습 요구사항

1. 사용할 환경 (환경 도구 / 환경 이름 또는 경로):
   예) venv / ./my-env,  conda / langchain-env

2. 실습 주제:

3. 실습 유형:
   아래 중 하나를 선택한다.
   - 학습/추론 스크립트
   - CLI 도구
   - 웹 앱 (Streamlit / Gradio / FastAPI)
   - 데이터 파이프라인
   - 기타: (직접 기입)

4. 실행 환경:
   예) 로컬, Colab, 서버

5. 사용할 데이터:
   아래 세 가지 유형 중 하나를 선택하고 관련 정보를 기재한다.

   [유형 A] 라이브러리/웹 자동 다운로드
     - 해당 라이브러리 또는 URL:
     예) sklearn.datasets, torchvision, HuggingFace datasets 등

   [유형 B] 사용자가 직접 제공 (로컬 파일)
     - 데이터 경로 (프로젝트 기준 상대 경로):
     예) ./data/images, ./data/train.csv

   [유형 C] Kaggle 대용량 데이터셋 (100MB 이상)
     - Kaggle 데이터셋 주소:
     예) https://www.kaggle.com/competitions/titanic

6. 선행 ipynb 실습:
   - 선행 ipynb 경로: (없으면 "없음")
   - 선행 실습에서 가져올 것: (코드 재활용 / 컨텍스트 참고 / 없음)

7. 핵심 기능:
   - (기능 1)
   - (기능 2)

8. 레퍼런스 자료:

9. 제약 사항:
