# 5단계: 학생 배포본 압축 (<과정명>_elice.zip)

## 목표

Elice 플랫폼 업로드를 위한 학생용 배포 zip을 생성한다.
강사 전용 자료(정답, 완성 코드, 중간 산출물)는 제외하고 학생에게 필요한 파일만 압축한다.

---

## 포함 / 제외 기준

### 포함

| 항목 | 조건 |
|---|---|
| `student/` | 항상 포함 (학생본 폴더) |
| `data/` | 디렉토리가 존재하는 경우 포함 |
| `configs/` | 디렉토리가 존재하는 경우 포함 |
| `.env` (student/ 내부) | 존재하는 경우 포함. 단, API 키 값은 반드시 `YOUR_API_KEY`로 교체. Base URL은 그대로 유지. |

### 제외

| 항목 | 이유 |
|---|---|
| `solution/` | 강사본 완성 코드 |
| `<실습명>_answer.md` | 정답 모음 |
| `README.md` | Elice 플랫폼에서 별도 제공 |
| `lecture.md` | Elice 플랫폼에서 별도 제공 |
| `requirements.txt` | Elice 환경에서 별도 관리 |
| `.biproducts/` | 중간 산출물 |

---

## zip 파일명 결정

`<과정명>`은 `base_instruction.md`의 프로젝트 제목 또는 실습명을 사용한다.
공백은 언더스코어(`_`)로 치환하고, 한글을 그대로 사용해도 무방하다.

최종 파일명: `<과정명>_elice.zip`

---

## 절차

### 1. 포함 파일 목록 확인

작업공간에 아래 항목이 있는지 확인한다.

- `student/` (필수)
- `data/` (있으면 포함)
- `configs/` (있으면 포함)

### 2. 과정명 결정

`.biproducts/artifacts/base_instruction.md`를 읽어 프로젝트 제목을 확인하고 zip 파일명을 결정한다.

### 3. zip 생성

작업공간 루트에서 아래 명령어를 실행한다. 포함 대상 파일/폴더만 명시적으로 지정한다.

```bash
cd <작업공간>
zip -r <과정명>_elice.zip student/
# data/ 가 있으면:
# zip -r <과정명>_elice.zip data/
# configs/ 가 있으면:
# zip -r <과정명>_elice.zip configs/
```

포함 항목이 확인된 경우 한 번에 묶는다:

```bash
cd <작업공간>
zip -r <과정명>_elice.zip student/ [data/] [configs/]
```

### 4. 상태 갱신 및 종료

zip 생성이 완료되면 아래를 수행하고 워크플로를 종료한다.

- `.biproducts/runtime/status.json`을 `step: 5`, `status: "completed"`로 갱신
- `changed_files`에 `<과정명>_elice.zip` 추가
- `.biproducts/runtime/last-response.md`에 최종 결과 요약 기록
- `.biproducts/runtime/events.jsonl`에 `file_written`, `workflow_completed` 이벤트 추가

> `<과정명>_elice.zip` 생성이 완료됐습니다.
> 이 파일을 Elice 플랫폼에 업로드하세요.

워크플로 종료.
