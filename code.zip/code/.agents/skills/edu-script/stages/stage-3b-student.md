# 3b단계: 학생본 생성 (student/ + <실습명>_answer.md)

## 목표

`solution/`의 완성 코드를 기반으로 학생본(`student/`)을 생성하고,
TODO 정답을 모은 `<실습명>_answer.md`를 작성한다.

---

## 변환 규칙

`solution/`의 모든 파일을 동일한 경로로 `student/`에 복사하되,
TODO 블록만 아래 규칙에 따라 치환한다.

### solution/ → student/ 치환

`solution/` 파일의 TODO 블록:

```python
#######
# 지시사항: ~~~~
#######
# [TODO-ANSWER]
정답_코드_여기()
# [/TODO-ANSWER]
```

`student/` 파일에서 `# [TODO-ANSWER]` ~ `# [/TODO-ANSWER]` 블록을 아래로 치환:

```python
#######
# 지시사항: ~~~~
#######
# YOUR CODE HERE
pass
```

### 치환 규칙 상세

- `#######` 지시사항 블록은 그대로 유지한다.
- `# [TODO-ANSWER]` 줄부터 `# [/TODO-ANSWER]` 줄까지(경계선 포함)를 `# YOUR CODE HERE\npass`로 대체한다.
- TODO 블록이 없는 파일은 그대로 복사한다.
- `student/` 파일에는 `# [TODO-ANSWER]`, `# [/TODO-ANSWER]` 마커가 남아 있으면 안 된다.

---

## answer.md 작성 규칙

`<실습명>_answer.md` 파일에 모든 TODO의 위치, 지시사항, 정답 코드를 순서대로 수록한다.

### 형식

```markdown
# <실습명> 정답 모음

## TODO 1

**파일**: `student/src/model.py`
**함수**: `MyModel.forward()`

지시사항: 모델의 forward()를 구현하세요.
힌트: self.layers에 x를 통과시킨 뒤 반환합니다.

```python
return self.layers(x)
```

## TODO 2

...
```

### 작성 원칙

- TODO 번호는 파일 순서, 파일 내 등장 순서 기준으로 부여한다.
- 파일 경로는 `student/` 기준으로 표기한다.
- 정답 코드 블록에는 `# [TODO-ANSWER]`, `# [/TODO-ANSWER]` 마커를 포함하지 않는다.

---

## 절차

### 1. student/ 생성

`solution/`의 파일 목록을 순회하며 아래를 수행한다.

1. 파일 내용을 읽는다.
2. `# [TODO-ANSWER]` ~ `# [/TODO-ANSWER]` 블록이 있으면 `# YOUR CODE HERE\npass`로 치환한다.
3. 치환된 내용을 `student/` 아래 동일 경로에 쓴다.

### 2. answer.md 작성

`solution/` 파일들을 다시 순회하며, `# [TODO-ANSWER]` ~ `# [/TODO-ANSWER]` 블록을 추출하여
위 형식에 따라 `<실습명>_answer.md`를 생성한다.

### 3. 검증

생성된 `student/` 파일에 `# [TODO-ANSWER]` 또는 `# [/TODO-ANSWER]` 문자열이 남아 있지 않은지 확인한다.

### 4. 작업 중단

파일 생성 완료 후 아래를 수행하고 반드시 작업을 멈춘다.

- `.biproducts/runtime/status.json`을 `step: "3b"`, `status: "needs_review"`로 갱신
- `changed_files`에 `student/` 하위 전체 파일과 `<실습명>_answer.md` 반영
- `.biproducts/runtime/last-response.md`에 생성 결과와 검토 요청 기록
- `.biproducts/runtime/events.jsonl`에 `file_written`, `awaiting_user_review` 이벤트 추가

> `student/`와 `<실습명>_answer.md`를 생성했습니다.
> 학생본의 TODO 위치와 지시사항이 적절한지, 정답 코드가 올바른지 검토해 주세요.
> 수정이 필요하면 `solution/`에서 수정한 뒤 알려주세요. 재생성하겠습니다.
> 완성되면 알려주세요.

### 5. 수정 반영

사용자가 `solution/` 수정을 알려오면 1~3단계를 다시 수행하여 `student/`와 `answer.md`를 재생성한다.
사용자의 최종 승인이 있어야만 4단계로 진행한다.

### 6. 다음 단계

`stages/stage-4-documentation.md`를 읽고 4단계를 시작한다.
