# 1단계: 요구사항 수집

## 목표

사용자의 스크립트 실습 요구사항을 구조화된 형식으로 수집하고,
선행 ipynb가 있으면 내용을 추출하여 참고 자료로 준비한다.

---

## 절차

### 1. 템플릿 파일 생성

`templates/base_instruction.md`를 복사해 작업 공간의 `.biproducts/artifacts/base_instruction.md`를 생성한다.

복사 명령:
```bash
mkdir -p <작업공간>/.biproducts/artifacts
cp <스킬경로>/templates/base_instruction.md <작업공간>/.biproducts/artifacts/base_instruction.md
```

### 2. 작업 중단

파일 생성 직후 아래를 수행하고 반드시 작업을 멈춘다.

- `.biproducts/runtime/status.json`을 `step: 1`, `status: "needs_review"`로 갱신
- `.biproducts/runtime/last-response.md`에 생성 파일과 검토 요청 요약 기록
- `.biproducts/runtime/events.jsonl`에 `file_written`, `awaiting_user_review` 이벤트 추가

> `.biproducts/artifacts/base_instruction.md` 파일을 생성했습니다. 내용을 작성한 뒤 완성됐다고 알려주세요.

### 3. 파일 읽기 및 검토

사용자가 완성을 알려오면 `.biproducts/artifacts/base_instruction.md`를 읽고 아래 체크리스트를 확인한다.

**체크리스트**
- [ ] 실습 유형이 명시됐는가 (학습/추론 스크립트, CLI, 웹 앱, 파이프라인 등)
- [ ] 실행 환경이 특정됐는가 (로컬, Colab, 서버)
- [ ] 핵심 기능이 1개 이상 있는가
- [ ] 데이터 로딩 유형이 명시됐는가 (유형 A/B/C 중 하나)
  - A: 라이브러리/웹 자동 다운로드 → 해당 라이브러리 또는 URL
  - B: 사용자 제공 로컬 파일 → 프로젝트 기준 상대 경로
  - C: Kaggle 대용량 (100MB 이상) → Kaggle 데이터셋 주소
- [ ] 선행 ipynb가 있다면 경로가 유효한가

항목이 불명확하면 사용자에게 질문해 보완한다.

### 4. 선행 ipynb 분석 (해당 시)

선행 ipynb가 있으면 `scripts/extract_notebook.py`를 사용해 내용을 추출한다.

```bash
python <스킬경로>/scripts/extract_notebook.py <선행ipynb경로> <작업공간>/.biproducts/artifacts/notebook_extract.md
```

에이전트가 ipynb를 직접 읽지 않고, 추출된 마크다운을 읽어 토큰을 절약한다.

#### 추출 모드 선택

| 상황 | 추출 모드 | 명령어 옵션 |
|------|----------|------------|
| 코드를 재활용할 때 (학습 스크립트, 파이프라인) | 전체 추출 | (옵션 없음) |
| 컨텍스트만 참고할 때 (웹 앱, CLI) | 요약 추출 | `--summary` |
| 코드만 필요할 때 | 코드만 추출 | `--code-only` |

#### 추출 결과 분석

추출된 `.biproducts/artifacts/notebook_extract.md`를 읽고, 스크립트 프로젝트에 활용할 내용을 정리한다.

| 상황 | 가져올 정보 |
|------|-----------|
| 학습/추론 스크립트 | 모델 정의, 전처리, 학습 루프, 하이퍼파라미터 등 핵심 코드 재활용 |
| 웹 앱 / CLI | ipynb의 목표와 결과를 컨텍스트로 참고, 코드는 새로 작성 |
| 데이터 파이프라인 | 데이터 경로, 전처리 로직 재활용 |

분석 결과를 `.biproducts/artifacts/base_instruction.md` 하단에 `## 선행 실습 분석` 섹션으로 추가한다.

### 5. 다음 단계

`stages/stage-2-design.md`를 읽고 2단계를 시작한다.
