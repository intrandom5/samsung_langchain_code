# 2단계: 프로젝트 설계 (.biproducts/artifacts/design.md)

## 목표

요구사항을 바탕으로 프로젝트의 디렉토리 구조, 파일 목록, 각 파일의 역할,
파일 간 의존 관계, 실행 방법을 설계한다.

---

## design.md 작성 규칙

- 프로젝트의 전체 구조를 트리 형태로 보여준다
- 각 파일의 역할과 핵심 로직을 간략히 설명한다
- 파일 간 의존 관계(import 흐름)를 명시한다
- 실행 진입점(엔트리포인트)을 명확히 표시한다
- 각 파일에 들어갈 핵심 함수/클래스 이름과 역할을 pseudo code 수준으로 기술한다

---

## 실습 유형별 전형적인 구조

아래는 참고용이며, 실습 내용에 따라 구조를 조정한다.

### 학습/추론 스크립트

```text
project/
├── solution/
│   ├── train.py              # 학습 진입점
│   ├── inference.py          # 추론 진입점
│   └── src/
│       ├── model.py          # 모델 정의
│       ├── dataset.py        # 데이터셋/전처리
│       ├── trainer.py        # 학습 루프
│       └── utils.py          # 유틸리티
├── configs/
│   └── default.yaml          # 하이퍼파라미터
├── data/
├── requirements.txt
└── README.md
```

### CLI 도구

```text
project/
├── solution/
│   ├── main.py               # CLI 진입점 (argparse)
│   └── src/
│       ├── processor.py      # 핵심 처리 로직
│       └── io.py             # 입출력 처리
├── requirements.txt
└── README.md
```

### 웹 앱 (Streamlit/Gradio/FastAPI)

```text
project/
├── solution/
│   ├── app.py                # 앱 진입점
│   └── src/
│       ├── model.py          # 모델/로직
│       └── utils.py          # 유틸리티
├── static/                   # 정적 파일 (필요 시)
├── templates/                # HTML 템플릿 (FastAPI, 필요 시)
├── requirements.txt
└── README.md
```

### 데이터 파이프라인

```text
project/
├── solution/
│   ├── run_pipeline.py       # 파이프라인 진입점
│   └── src/
│       ├── extract.py        # 데이터 추출
│       ├── transform.py      # 데이터 변환
│       └── load.py           # 데이터 적재
├── configs/
│   └── pipeline.yaml         # 파이프라인 설정
├── requirements.txt
└── README.md
```

---

## design.md 템플릿

```markdown
# 프로젝트 설계

## 프로젝트 구조

(트리 형태 — solution/ 기준으로 작성. student/는 3b단계에서 자동 생성되므로 생략)

## 파일별 역할

| 파일 | 역할 | 핵심 함수/클래스 |
|------|------|-----------------|
| solution/train.py | 학습 진입점 | `main()`: argparse로 설정 로딩 → Trainer 실행 |
| solution/src/model.py | 모델 정의 | `MyModel(nn.Module)`: forward() 구현 |
| ... | ... | ... |

## 의존 관계

(import 흐름 또는 호출 순서)

예시:
solution/train.py → solution/src/model.py, solution/src/dataset.py, solution/src/trainer.py
solution/src/trainer.py → solution/src/model.py, solution/src/dataset.py

## 실행 방법

(엔트리포인트와 실행 명령어)

예시:
python solution/train.py --config configs/default.yaml
python solution/inference.py --model-path outputs/model.pt --input data/test.csv
```

---

## 절차

### 1. design.md 초안 작성

`.biproducts/artifacts/base_instruction.md`(및 `notebook_extract.md`, 해당 시)를 읽고
위 템플릿에 따라 `.biproducts/artifacts/design.md`를 생성한다.

선행 ipynb가 있는 경우:
- `notebook_extract.md`에서 추출된 코드 구조를 참고하여 모듈 분리를 설계한다
- 노트북의 선형 흐름을 모듈 구조로 재구성한다 (예: 전처리 코드 → `src/dataset.py`, 모델 코드 → `src/model.py`)

### 2. 작업 중단

파일 생성 직후 아래를 수행하고 반드시 작업을 멈춘다.

- `.biproducts/runtime/status.json`을 `step: 2`, `status: "needs_review"`로 갱신
- `.biproducts/runtime/last-response.md`에 변경 요약과 검토 요청 기록
- `.biproducts/runtime/events.jsonl`에 `file_written`, `awaiting_user_review` 이벤트 추가

> `.biproducts/artifacts/design.md`를 생성했습니다. 프로젝트 구조와 파일 역할을 검토하고,
> 수정이 필요하면 직접 수정하거나 알려주세요. 완성되면 알려주세요.

### 3. 사용자 수정 사항 검토

사용자가 완성을 알려오면 `.biproducts/artifacts/design.md`를 다시 읽고 아래를 수행한다.

#### 검토 체크리스트

- [ ] 프로젝트 구조가 트리 형태로 명시됐는가
- [ ] 모든 파일의 역할이 기술됐는가
- [ ] 핵심 함수/클래스가 pseudo code 수준으로 정의됐는가
- [ ] 파일 간 의존 관계가 명확한가 (순환 의존 없음)
- [ ] 실행 진입점과 명령어가 명시됐는가
- [ ] 불필요하게 파일이 많지 않은가 (과도한 추상화 방지)

#### 개선 제안

검토 결과 개선이 필요한 부분이 있으면 사용자에게 구체적으로 제안한다.

제안 예시:
- "src/utils.py에 기능이 하나뿐이라면 사용하는 모듈에 직접 포함하는 것이 나을 수 있습니다"
- "train.py와 inference.py의 데이터 로딩 코드가 중복될 수 있으므로 src/dataset.py로 분리하면 좋겠습니다"
- "config 파일 없이 argparse만으로 충분해 보입니다. configs/ 디렉토리를 제거할까요?"

사용자가 제안을 수락하면 design.md에 반영한다.
사용자가 최종 승인해야만 3단계로 진행한다.

### 4. 다음 단계

`stages/stage-3-implementation.md`를 읽고 3단계를 시작한다.
