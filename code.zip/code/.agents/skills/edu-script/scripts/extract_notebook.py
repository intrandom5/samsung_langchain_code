"""주피터 노트북(.ipynb)에서 코드와 마크다운을 추출하는 도구.

선행 ipynb 실습의 내용을 스크립트 프로젝트에 활용할 때,
에이전트가 ipynb를 직접 읽는 대신 이 스크립트로 추출한 텍스트를 읽는다.
토큰 절약과 구조화된 정보 제공이 목적이다.

사용법:
    python extract_notebook.py <입력.ipynb> <출력.md>
    python extract_notebook.py notebook.ipynb extracted.md
    python extract_notebook.py notebook.ipynb extracted.md --code-only
    python extract_notebook.py notebook.ipynb extracted.md --summary

옵션:
    --code-only   코드 셀만 추출 (마크다운 셀 제외)
    --summary     각 셀의 첫 줄/첫 문장만 추출 (전체 내용 대신 요약)

산출물:
    구조화된 마크다운 파일. 셀 번호, 셀 유형, 내용을 포함한다.
"""
import json
import sys
from pathlib import Path


def read_notebook(filepath: Path) -> dict:
    """ipynb 파일을 읽어 노트북 객체를 반환한다."""
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


def extract_cells(nb: dict, code_only: bool = False, summary: bool = False) -> list[dict]:
    """노트북에서 셀 정보를 추출한다.

    각 셀은 다음 키를 갖는다:
    - index: 셀 번호 (1부터)
    - type: "code" | "markdown"
    - source: 셀 내용
    - outputs: 코드 셀의 출력 (텍스트만, 요약 시 생략)
    """
    cells = nb.get("cells", [])
    results = []

    for i, cell in enumerate(cells, 1):
        cell_type = cell.get("cell_type", "")
        source = "".join(cell.get("source", []))

        if not source.strip():
            continue

        if code_only and cell_type != "code":
            continue

        # 요약 모드: 각 셀의 핵심만 추출
        if summary:
            source = _summarize_cell(source, cell_type)

        entry = {
            "index": i,
            "type": cell_type,
            "source": source,
        }

        # 코드 셀의 텍스트 출력 추출 (요약 모드에서는 생략)
        if cell_type == "code" and not summary:
            outputs = _extract_text_outputs(cell.get("outputs", []))
            if outputs:
                entry["outputs"] = outputs

        results.append(entry)

    return results


def _summarize_cell(source: str, cell_type: str) -> str:
    """셀 내용을 요약한다."""
    lines = source.strip().split("\n")

    if cell_type == "markdown":
        # 마크다운: 헤더 또는 첫 문장만
        for line in lines:
            stripped = line.strip()
            if stripped:
                return stripped
        return ""

    # 코드: 주석 첫 줄 + import 목록 또는 함수/클래스 정의만
    summary_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#"):
            summary_lines.append(stripped)
            break

    for line in lines:
        stripped = line.strip()
        if any(stripped.startswith(kw) for kw in
               ["import ", "from ", "def ", "class "]):
            summary_lines.append(stripped)

    return "\n".join(summary_lines) if summary_lines else lines[0]


def _extract_text_outputs(outputs: list) -> str:
    """셀 출력에서 텍스트만 추출한다."""
    text_parts = []

    for output in outputs:
        output_type = output.get("output_type", "")

        if output_type == "stream":
            text_parts.append("".join(output.get("text", [])))

        elif output_type in ("execute_result", "display_data"):
            data = output.get("data", {})
            if "text/plain" in data:
                text = data["text/plain"]
                if isinstance(text, list):
                    text = "".join(text)
                text_parts.append(text)

        elif output_type == "error":
            ename = output.get("ename", "")
            evalue = output.get("evalue", "")
            text_parts.append(f"[ERROR] {ename}: {evalue}")

    combined = "\n".join(text_parts).strip()
    # 출력이 너무 길면 잘라낸다
    max_lines = 30
    lines = combined.split("\n")
    if len(lines) > max_lines:
        combined = "\n".join(lines[:max_lines]) + f"\n... ({len(lines) - max_lines}줄 생략)"

    return combined


def format_output(cells: list[dict], notebook_name: str) -> str:
    """추출된 셀을 마크다운 형식으로 포맷한다."""
    lines = [f"# {notebook_name} - 노트북 추출 결과\n"]

    code_count = sum(1 for c in cells if c["type"] == "code")
    md_count = sum(1 for c in cells if c["type"] == "markdown")
    lines.append(f"코드 셀: {code_count}개 | 마크다운 셀: {md_count}개 | 전체: {len(cells)}개\n")
    lines.append("---\n")

    for cell in cells:
        cell_type_label = "CODE" if cell["type"] == "code" else "MD"
        lines.append(f"## Cell {cell['index']} [{cell_type_label}]\n")

        if cell["type"] == "code":
            lines.append(f"```python\n{cell['source']}\n```\n")
        else:
            lines.append(f"{cell['source']}\n")

        if cell.get("outputs"):
            lines.append(f"**출력:**\n```\n{cell['outputs']}\n```\n")

        lines.append("---\n")

    return "\n".join(lines)


def extract(input_path: str, output_path: str,
            code_only: bool = False, summary: bool = False) -> None:
    """ipynb를 읽고 추출 결과를 마크다운으로 저장한다."""
    src = Path(input_path)
    if not src.exists():
        print(f"파일을 찾을 수 없습니다: {src}")
        sys.exit(1)

    if not src.suffix == ".ipynb":
        print(f"ipynb 파일이 아닙니다: {src}")
        sys.exit(1)

    nb = read_notebook(src)
    cells = extract_cells(nb, code_only=code_only, summary=summary)

    if not cells:
        print("추출할 셀이 없습니다.")
        sys.exit(1)

    result = format_output(cells, src.stem)

    dst = Path(output_path)
    dst.parent.mkdir(parents=True, exist_ok=True)
    with open(dst, "w", encoding="utf-8") as f:
        f.write(result)

    mode_label = ""
    if code_only:
        mode_label = " (코드만)"
    elif summary:
        mode_label = " (요약)"

    print(f"추출 완료{mode_label}:")
    print(f"  입력: {src}")
    print(f"  출력: {dst}")
    print(f"  코드 셀: {sum(1 for c in cells if c['type'] == 'code')}개")
    print(f"  마크다운 셀: {sum(1 for c in cells if c['type'] == 'markdown')}개")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("사용법: python extract_notebook.py <입력.ipynb> <출력.md> [--code-only|--summary]")
        sys.exit(1)

    code_only = "--code-only" in sys.argv
    summary = "--summary" in sys.argv

    extract(sys.argv[1], sys.argv[2], code_only=code_only, summary=summary)
