---
name: edu-script
description: >
  교육용 스크립트 프로젝트를 단계별로 생성한다. 학습/추론 스크립트, CLI 도구,
  웹 앱(Streamlit/Gradio/FastAPI), 데이터 파이프라인 등 스크립트 단위 실습을
  프로젝트 폴더 구조로 완성한다. 선행 ipynb 실습의 후속으로 진행할 수도 있다.
  사용자 검토와 승인이 필요한 단계마다 반드시 작업을 멈추고 응답을 기다린다.
---

# 교육용 스크립트 프로젝트 생성 스킬

## 이 스킬의 목적

스크립트 단위 실습을 프로젝트 폴더 구조로 제작한다. 노트북(ipynb)이 아닌
실행 가능한 스크립트(.py 등)로 구성되는 실습을 다룬다.

## 실행 환경

이 스킬은 Claude Code, Cursor, Codex, OpenCode 등 여러 에이전트 환경에서 사용된다.

**Subagent 위임은 Claude Code 전용이다.** 현재 환경이 Claude Code인지는 `Agent` 도구 사용 가능 여부로 판단한다.

| 환경 | Subagent 사용 | 처리 방식 |
|---|---|---|
| Claude Code | 가능 | subagent에 위임 |
| 그 외 | 불가 | 직접 수행 |

---

## 단계 요약 및 중단 지점

각 단계의 상세 지침은 `stages/` 디렉토리의 파일을 읽는다.

| 단계 | 파일 | 산출물 | 중단 시점 | 재개 조건 |
|---|---|---|---|---|
| 0 | (이 파일) | 작업 공간 폴더 | 없음 | 바로 1단계로 |
| 1 | `stages/stage-1-requirements.md` | `base_instruction.md` + 선행 ipynb 분석 | base_instruction.md 생성 직후 | 사용자가 작성 완료를 알림 |
| 2 | `stages/stage-2-design.md` | `design.md` (프로젝트 설계) | design.md 생성 직후 | 사용자가 검토/수정 완료를 알림 |
| 3 | `stages/stage-3-implementation.md` | `solution/` 완성 스크립트 + `requirements.txt` | 실행 테스트 완료 직후 | 사용자가 검토/수정 완료를 알림 |
| 3b | `stages/stage-3b-student.md` | `student/` 학생본 + `<실습명>_answer.md` | 학생본 생성 직후 | 사용자가 검토/수정 완료를 알림 |
| 4 | `stages/stage-4-documentation.md` | `README.md` | 문서 생성 완료 | 바로 5단계로 |
| 5 | `stages/stage-5-zip.md` | `<과정명>_elice.zip` 생성 완료 | 워크플로 종료 |

---

## 0단계: 작업 공간 설정 및 모드 결정

### 새로 만들기 vs 선행 ipynb 후속

스킬을 시작할 때 반드시 아래 둘 중 하나를 확인한다.

- **새로 만들기**: 처음부터 스크립트 프로젝트를 제작한다.
- **선행 ipynb 후속**: 기존 ipynb 실습을 기반으로 스크립트 프로젝트를 만든다.

사용자가 ipynb 파일을 언급하거나 "스크립트로 변환", "후속", "이어서" 등을 표현하면 후속 모드로 진행한다. 불확실하면 질문한다.

---

### 작업 공간 구조

```text
<작업공간>/
├── .biproducts/
│   ├── artifacts/
│   │   ├── base_instruction.md   # 사용자 요구사항 (1단계)
│   │   ├── notebook_extract.md   # 선행 ipynb 추출 결과 (1단계, 해당 시)
│   │   └── design.md             # 프로젝트 설계 (2단계)
│   └── runtime/
│       ├── status.json           # 현재 단계/상태
│       ├── last-response.md      # 최근 응답 요약
│       ├── execution-log.md      # 실행 결과 로그
│       └── events.jsonl          # 이벤트 로그
├── solution/                     # 강사본: 완성 코드 (정답 포함)
│   ├── <진입점>.py
│   └── src/                      # 실습 유형에 따라 구조 결정
├── student/                      # 학생본: TODO 포함 (3b단계에서 생성)
│   ├── <진입점>.py
│   └── src/
├── <실습명>_answer.md            # TODO 정답 모음 (3b단계에서 생성)
├── data/                         # 데이터 (필요 시)
├── configs/                      # 설정 파일 (필요 시)
├── requirements.txt              # 의존성
└── README.md                     # 사용자 안내 문서
```

`solution/` 내부 구조(`src/`, 하위 디렉토리, 파일 수)는 실습 유형에 따라 달라진다.
2단계(설계)에서 구체적인 구조를 결정한다.

작업 공간 생성 후 `stages/stage-1-requirements.md`를 읽고 1단계를 시작한다.

---

## 명시적 상태 보고 규칙

이 스킬은 각 실습 폴더의 `.biproducts/runtime/` 아래에 상태를 기록한다.
상태 파일은 전역 위치가 아니라 반드시 현재 실습 작업공간 안에 있어야 한다.

### 상태 파일

- `status.json`
  - 현재 단계 번호
  - 현재 상태 (`in_progress`, `needs_review`, `completed`, `blocked`)
  - 최근 업데이트 시각
  - 최근 변경 파일 목록
  - 다음 사용자 액션
- `last-response.md`
  - 현재 단계에서 사용자에게 보여줄 최근 요약
  - 무엇을 생성/수정했는지
  - 무엇을 검토해달라는지
- `events.jsonl`
  - 단계 시작
  - 파일 생성/수정
  - 사용자 검토 대기
  - 단계 완료

### 상태 업데이트 원칙

- 각 단계를 시작할 때 `status.json`을 해당 단계의 `in_progress`로 갱신한다
- 파일을 생성하거나 수정한 뒤에는 `changed_files`를 갱신한다
- 사용자 검토나 승인 때문에 멈출 때는 반드시
  - `status.json`을 `needs_review`로 갱신하고
  - `last-response.md`를 갱신하고
  - `events.jsonl`에 이벤트를 1줄 추가한다
- 전체 워크플로가 끝나면 `status.json`을 `completed`로 기록한다

### `status.json` 예시

```json
{
  "workflow": "edu-script",
  "step": 2,
  "status": "needs_review",
  "updated_at": "2026-03-25T05:00:00Z",
  "changed_files": [
    ".biproducts/artifacts/design.md"
  ],
  "next_action": "design.md를 검토하고 수정이 끝나면 알려주세요."
}
```

### `events.jsonl` 예시

```jsonl
{"ts":"2026-03-25T04:58:00Z","type":"step_started","step":2}
{"ts":"2026-03-25T04:59:00Z","type":"file_written","path":".biproducts/artifacts/design.md"}
{"ts":"2026-03-25T05:00:00Z","type":"awaiting_user_review","step":2}
```

---

## 전 단계 공통 금지 사항

- 반말 사용 금지. 설명은 존댓말, 주석이나 요약형 문장은 체언 종결로 작성
- 이모티콘 사용 금지 (코드, 주석, 마크다운 어디에도)
- 사용자 승인 없이 단계 건너뛰기 금지
- LLM / 에이전트 실습에서 LLM에게 입력값을 deterministic하게 입력하지 말고, input() 함수를 통해 사용자가 텍스트를 입력하도록 할 것
- 학습이 포함될 경우 테스트 실행은 극소수 데이터로 수행 (전체 데이터 중 8개만 사용, batch_size=4, epoch=2). 단, 최종 스크립트에서는 전체 데이터를 활용하도록 구성
- 무의미한 print 작성 금지 (예: `print("라이브러리 임포트 완료!")`)
- `requirements.txt` 작성 시 반드시 버전을 명시하고 `==`으로 고정. `>=` 사용 금지. (예: `langchain==0.3.21`, `openai==1.75.0`)
