# 5단계: 주피터 노트북 변환

## 목표

`.biproducts/artifacts/run.py`(및 `run_todo_*.py`)를 주피터 노트북으로 변환하고, 학생본/강사본/정답 문서를 생성한다.

변환은 `scripts/convert.py` 스크립트를 실행한다.

---

## 변환 규칙

### 일반 셀 (`### Cell`)

| `.biproducts/artifacts/run.py` 요소 | 노트북 변환 결과 |
|---|---|
| `### Cell` + docstring(`"""..."""`) | 마크다운 셀 |
| `### Cell` + 일반 코드 | 코드 셀 |
| 코드 내 `#` 주석 | 코드 셀 내 주석으로 유지 |

### TODO 셀 (`### Cell [TODO]`)

TODO 셀은 학생본과 강사본에서 다르게 변환된다.

| 요소 | 학생본 (`.ipynb`) | 강사본 (`_full.ipynb`) |
|---|---|---|
| docstring (힌트) | 마크다운 셀 (그대로) | 마크다운 셀 (그대로) |
| `# [TODO-ANSWER]` ~ `# [/TODO-ANSWER]` | 빈 코드 셀 (`# 여기에 코드를 작성하세요`) | 코드 셀 (정답 코드 포함) |

---

## 산출물

하나의 run.py에서 세 가지 산출물을 생성한다.

| 산출물 | 설명 |
|---|---|
| `<실습명>.ipynb` | 학생본. TODO 셀은 빈 코드 셀로 변환 |
| `<실습명>_full.ipynb` | 강사본. 모든 정답 코드 포함 |
| `<실습명>_answer.md` | TODO 번호별 정답 코드 모음 문서 |

skeleton 파일(`run_todo_*.py`)이 있으면 각각에 대해서도 동일하게 세 가지 산출물을 생성한다.

| 산출물 | 설명 |
|---|---|
| `<실습명>_todo_<이름>.ipynb` | skeleton 학생본 |
| `<실습명>_todo_<이름>_full.ipynb` | skeleton 강사본 |
| `<실습명>_todo_<이름>_answer.md` | skeleton 정답 문서 |

### answer.md 형식

```markdown
# <실습명> - 정답 모음

## TODO 1: <힌트 제목>

```python
<정답 코드>
```

## TODO 2: <힌트 제목>

```python
<정답 코드>
```
```

---

## 절차

### 1. 메인 노트북 변환

```bash
python <스킬경로>/scripts/convert.py .biproducts/artifacts/run.py <실습명>.ipynb
```

스크립트가 자동으로 수행하는 것:
1. ipynb 호환성 검증 (금지 패턴 7개 + docstring/코드 혼합 검사)
2. `### Cell` / `### Cell [TODO]` 기준으로 run.py 분할
3. 일반 셀: docstring → 마크다운 셀, 코드 → 코드 셀
4. TODO 셀: 학생본에서는 정답 제거 + 빈 코드 셀, 강사본에서는 정답 유지
5. 커널 메타데이터(Python 3) 설정
6. `nbformat.validate()` 구조 검증
7. 셀 수 요약 출력
8. 세 가지 산출물 (학생본, 강사본, answer.md) 동시 생성

### 2. skeleton 노트북 변환 (해당 시)

`.biproducts/artifacts/run_todo_*.py` 파일이 있으면 각각에 대해 동일한 변환을 수행한다.

#### 파일명 매핑 규칙

입력 파일명에서 `run_todo_` 접두어를 `<실습명>_todo_`로 교체한다.

| 입력 (run 스크립트) | 출력 (노트북) |
| --- | --- |
| `.biproducts/artifacts/run_todo_<이름>.py` | `<실습명>_todo_<이름>.ipynb` (학생본) |
| (동일) | `<실습명>_todo_<이름>_full.ipynb` (강사본) |
| (동일) | `<실습명>_todo_<이름>_answer.md` (정답) |

```bash
python <스킬경로>/scripts/convert.py .biproducts/artifacts/run_todo_fashion.py <실습명>_todo_fashion.ipynb
```

### 3. 오류 처리

스크립트가 오류를 반환하면:
- **호환성 위반**: 출력된 라인 번호를 확인하고 run.py를 수정한 뒤 재실행
- **셀 없음**: `### Cell` 구분자가 올바른지 확인
- **nbformat 검증 실패**: 셀 구조를 점검

### 4. 변환 결과 확인

변환 완료 후 아래를 확인한다.

- 학생본(`<실습명>.ipynb`)과 강사본(`<실습명>_full.ipynb`)이 모두 존재하는가
- answer.md가 생성됐는가
- 출력된 셀 수가 예상과 일치하는가
- 첫 번째 셀이 마크다운(제목/학습 목표)인가
- TODO 셀이 학생본에서 빈 코드 셀로 올바르게 변환됐는가

실습에 외부 패키지가 필요하면 루트의 `requirements.txt`도 함께 생성하거나 갱신한다.

### 5. 다음 단계

다음을 수행한 뒤 `stages/stage-6-reference.md`를 읽고 최종 사용자 문서를 작성한다.

- `.biproducts/runtime/status.json`을 `step: 5`, `status: "completed"`로 갱신
- `changed_files`에 생성된 모든 노트북 파일, answer.md, `requirements.txt` 반영
- `.biproducts/runtime/last-response.md`에 생성한 최종 산출물 요약 기록
- `.biproducts/runtime/events.jsonl`에 생성 이벤트 추가
