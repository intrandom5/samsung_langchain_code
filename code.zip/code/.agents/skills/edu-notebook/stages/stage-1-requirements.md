# 1단계: 요구사항 수집

## 목표

사용자의 실습 요구사항을 구조화된 형식으로 수집한다.

---

## 절차

### 1. 템플릿 파일 생성

`templates/base_instruction.md`를 복사해 작업 공간의 `.biproducts/artifacts/base_instruction.md`를 생성한다.

복사 명령:
```bash
mkdir -p <작업공간>/.biproducts/artifacts
cp <스킬경로>/templates/base_instruction.md <작업공간>/.biproducts/artifacts/base_instruction.md
```

### 2. 작업 중단

파일 생성 직후 아래 메시지를 출력하고 반드시 작업을 멈춘다.

멈추기 전에 아래를 반드시 수행한다.

- `.biproducts/runtime/status.json`을 `step: 1`, `status: "needs_review"`로 갱신
- `.biproducts/runtime/last-response.md`에 생성 파일과 검토 요청 요약 기록
- `.biproducts/runtime/events.jsonl`에 `file_written`, `awaiting_user_review` 이벤트 추가

> `.biproducts/artifacts/base_instruction.md` 파일을 생성했습니다. 내용을 작성한 뒤 완성됐다고 알려주세요.

### 3. 파일 읽기 및 검토

사용자가 완성을 알려오면 `.biproducts/artifacts/base_instruction.md`를 읽고 아래 체크리스트를 확인한다.

**체크리스트**
- [ ] 환경 도구와 환경 이름이 명시됐는가
- [ ] 실습 주제가 구체적인가
- [ ] 플랫폼이 특정됐는가 (예: Google Colab, 로컬)
- [ ] 데이터 로딩 유형이 명시됐는가 (유형 A/B/C 중 하나)
  - A: 라이브러리/웹 자동 다운로드 → 해당 라이브러리 또는 URL
  - B: 사용자 제공 로컬 파일 → 노트북 기준 상대 경로
  - C: Kaggle 대용량 (100MB 이상) → Kaggle 데이터셋 주소

항목이 불명확하면 사용자에게 질문해 보완한 뒤 2단계로 넘어간다.

### 4. 다음 단계

`stages/stage-1b-lecture.md`를 읽고 1b단계(강의 노트 작성)를 시작한다.
