# 리메이크 R1: 작업 범위 확정 및 실행

## 목표

사용자가 선택한 체크리스트를 바탕으로 두 경로 중 하나로 진행한다.

---

## 경로 결정

아래 기준으로 경로를 판단한다.

| 조건 | 경로 |
|---|---|
| "마크다운 셀 보강" 또는 "새 섹션 추가"가 선택됨 | 경로 A |
| 위 두 항목이 모두 선택되지 않음 | 경로 B |

---

## 경로 A: 노트북 구조 변경 포함

노트북을 run.py로 역변환한 뒤 기존 워크플로(4단계 → 5단계 → 6단계)를 따른다.

### A-1. 역변환: .ipynb → run.py

`references/nb-to-runpy.md`에 포함된 역변환 스크립트를 실행한다.

```bash
python3 nb_to_runpy.py <기존노트북>.ipynb .biproducts/artifacts/run.py
```

### A-2. 새 섹션 추가 (선택된 경우에만)

"새 섹션 추가"가 선택됐으면 사용자에게 아래를 질문하고 반드시 작업을 멈춘다.

```
어떤 내용을 추가할까요? 아래를 알려주세요.
1. 추가할 섹션의 제목 또는 주제
2. 삽입 위치 (예: "데이터 로딩 셀 뒤", "학습 함수 앞")
3. 구현할 내용에 대한 설명이나 참고 코드 (있으면)
```

사용자 응답을 받으면 `.biproducts/artifacts/run.py`의 해당 위치에 `### Cell` 블록을 삽입한다. 이때 마크다운 셀(docstring)과 코드 셀을 모두 작성한다. 코드 작성 시 `stages/stage-3-scripting.md`의 run.py 작성 규칙을 따른다 (EAFP 스타일, ipynb 호환성 등).

멈추기 전에 아래를 수행한다.
- `.biproducts/runtime/status.json`을 `step: "R1-A2"`, `status: "needs_review"`로 갱신
- `.biproducts/runtime/last-response.md`에 삽입한 섹션 목록 기록
- `.biproducts/runtime/events.jsonl`에 `awaiting_user_review` 이벤트 추가

사용자가 확인하면 다음 단계로 진행한다.

### A-3. 전체 run.py 실행 검증

`.biproducts/artifacts/run.py` 전체를 실행해 오류가 없는지 확인한다.

- 오류 발생 시 수정 후 재실행한다
- 결과는 `.biproducts/runtime/execution-log.md`에 기록한다 (형식은 3단계와 동일)
- 새로 설치한 패키지가 있으면 `requirements.txt`에 반영한다

### A-4. 다음 단계

`stages/stage-4-markdown.md`를 읽고 4단계(마크다운 셀 작성)를 시작한다.

"마크다운 셀 보강"이 선택되지 않았더라도, 새 섹션을 추가했다면 해당 셀의 마크다운은 반드시 4단계 기준으로 작성한다.

---

## 경로 B: 산출물만 생성

노트북 내용은 그대로 유지하고, 선택된 산출물만 생성한다.

각 항목을 아래 순서로 처리한다.

### B-1. requirements.txt (선택된 경우)

`.biproducts/artifacts/base_instruction.md`와 기존 노트북의 import 목록을 바탕으로 `requirements.txt`를 작업 공간 루트에 생성한다.

### B-2. student.ipynb (선택된 경우)

`stages/stage-5-notebook.md`의 "학생용 버전 생성" 절차를 따른다.

### B-3. README.md (선택된 경우)

`stages/stage-6-reference.md`를 읽고 README를 작성한다.

### B-4. 완료

모든 산출물 생성이 끝나면 아래를 수행하고 워크플로를 종료한다.

- `.biproducts/runtime/status.json`을 `step: "R1-B"`, `status: "completed"`로 갱신
- `changed_files`에 생성된 파일 목록 반영
- `.biproducts/runtime/last-response.md`에 생성 결과 요약 기록
- `.biproducts/runtime/events.jsonl`에 `workflow_completed` 이벤트 추가
