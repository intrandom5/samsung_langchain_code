# 3단계: 파이썬 스크립트 완성 및 디버깅 (.biproducts/artifacts/run.py)

## 목표

`.biproducts/artifacts/plan.py`를 기반으로 실제 동작하는 `.biproducts/artifacts/run.py`를 작성하고, 오류 없이 실행될 때까지 디버깅한다.

---

## run.py 작성 규칙

- 셀 구분: `### Cell` (`.biproducts/artifacts/plan.py`와 동일한 구분자 유지)
- 마크다운 셀: docstring(`"""..."""`)으로 작성 (5단계 변환 시 마크다운 셀로 전환됨)
- 주석은 한국어로 작성
- 이모티콘 절대 사용 금지
- 무의미한 print 금지
- figure에 한글 폰트 사용 금지(title, xlabel, ylabel). matplotlib은 한글 폰트를 지원하지 않음
- EAFP 스타일 준수: 타입 체크(`isinstance`, `type()`), 과도한 if/else 분기, 불필요한 try/except 블록을 지양한다. 초보 학생이 읽기 쉬운 직선적인 코드를 작성한다
- 학습 대상이 API/SDK/라이브러리 호출 형태 자체인 노트북에서는 그 호출을 헬퍼 함수로 감싸지 않는다. 같은 호출이 여러 셀에서 반복되더라도 raw 호출(인자 이름과 위치가 그대로 보이는 형태)을 셀마다 풀어 쓴다. 헬퍼로 감싸면 학생이 매개변수가 어디에 어떻게 들어가는지 못 보게 되어 본질을 호도한다. 다만 학습 대상이 아닌 진짜 boilerplate(스타일 적용, 공통 전처리 등)는 헬퍼로 묶어도 무방하다

---

## ipynb 호환성 규칙 (필수)

run.py는 5단계에서 기계적으로 ipynb로 변환된다. subagent가 아닌 스크립트가 변환하므로,
run.py가 곧 ipynb의 쌍둥이(twin)여야 한다. 아래 규칙을 반드시 지킨다.

### 금지 패턴 — ipynb에서 동작하지 않는 코드

| 금지 패턴 | 이유 | 대체 방법 |
|-----------|------|----------|
| `__file__` | 노트북에 `__file__` 없음 | `Path(".")` 또는 상대 경로 직접 사용 |
| `sys.argv` | 노트북에 커맨드라인 인자 없음 | 변수로 직접 선언 |
| `if __name__ == "__main__":` | 노트북에서 항상 `__main__`이지만 가드 불필요 | 최상위 레벨에 코드 배치 |
| `argparse` | 노트북에서 사용 불가 | 변수로 직접 선언 |
| `exit()` / `sys.exit()` | 노트북 커널 종료됨 | 사용하지 않음 |
| 상대 import (`from . import`) | 노트북에서 패키지 구조 없음 | 절대 경로 import 또는 셀 내 정의 |
| 멀티프로세싱 (`multiprocessing`) | 노트북에서 제한적 | `num_workers=0` 사용 또는 주의 안내 |
| 무한 루프 / 장시간 blocking | 노트북 셀이 영원히 실행됨 | 종료 조건 명시 |

### 필수 패턴 — ipynb에서 기대되는 코드

| 필수 패턴 | 이유 |
|-----------|------|
| 모든 import는 첫 번째 코드 셀에 모은다 | 노트북 재시작 후 순서대로 실행할 때 의존성 확보 |
| 각 `### Cell`은 독립적으로 의미 있는 단위 | 노트북 셀은 개별 실행 가능해야 함 |
| 변수/함수는 사용 전 셀에서 정의 | 셀 순서 의존성 명확화 |
| `plt.show()` 명시 호출 | 노트북에서 인라인 출력 보장 |
| DataLoader `num_workers=0` | 노트북에서 멀티프로세스 문제 방지 |
| 경로는 노트북 파일 위치 기준 상대경로 | 노트북 실행 위치 = 노트북 파일 위치 |

### 자가 검증 체크리스트 (코드 작성 완료 후)

run.py 작성이 끝나면 변환 전에 반드시 아래를 확인한다.

- [ ] `__file__`, `sys.argv`, `argparse` 사용하지 않았는가
- [ ] `if __name__ == "__main__":` 가드가 없는가
- [ ] `exit()` / `sys.exit()` 호출이 없는가
- [ ] 상대 import (`from .xxx`)가 없는가
- [ ] 모든 import가 첫 번째 코드 셀에 있는가
- [ ] DataLoader의 `num_workers`가 0인가 (해당 시)
- [ ] `plt.show()`가 시각화 셀마다 있는가 (해당 시)
- [ ] 모든 경로가 상대 경로인가
- [ ] 각 `### Cell` / `### Cell [TODO]` 구분자가 정확한가
- [ ] docstring(`"""..."""`)과 코드가 혼합된 셀이 없는가 (하나의 셀은 docstring만 또는 코드만). 단, `### Cell [TODO]`는 docstring(힌트) + 정답 코드가 함께 있어야 한다
- [ ] `### Cell [TODO]` 셀마다 `# [TODO-ANSWER]` ~ `# [/TODO-ANSWER]` 블록이 있는가
- [ ] TODO 힌트에 코드 스니펫이 포함되지 않았는가 (글로만 설명)

---

## 데이터 로딩 패턴

`base_instruction.md`의 데이터 유형(A/B/C)에 따라 아래 패턴을 사용한다.

### 유형 A: 라이브러리/웹 자동 다운로드

다운로드 코드를 노트북에 직접 포함한다.

```python
# sklearn 예시
from sklearn.datasets import fetch_california_housing
data = fetch_california_housing(as_frame=True)

# torchvision 예시
from torchvision.datasets import CIFAR10
dataset = CIFAR10(root="./data", train=True, download=True, transform=transform)

# HuggingFace 예시
from datasets import load_dataset
dataset = load_dataset("imdb")
```

### 유형 B: 사용자 제공 로컬 파일

노트북 위치를 기준으로 상대 경로를 사용한다. 경로는 상단 셀에서 변수로 선언한다.

```python
import os
data_path = "./data"
train_csv = os.path.join(data_path, "train.csv")
images_dir = os.path.join(data_path, "images")
```

### 유형 C: Kaggle 대용량 데이터셋 (100MB 이상)

Kaggle 환경이나 수동 다운로드 후 경로가 세션마다 달라질 수 있으므로, `root_dir`을 상단 셀에서 사용자가 직접 입력하도록 안내한다.

```python
import os
# 데이터셋 루트 경로를 직접 입력하세요.
# 예) Kaggle 환경: "/kaggle/input/titanic"
#     로컬: "/Users/yourname/datasets/titanic"
root_dir = "디렉토리를 복사해주세요"

train_csv = os.path.join(root_dir, "train.csv")
images_dir = os.path.join(root_dir, "images")
```

---

## 테스트 실행 기준

코드가 오류 없이 실행되는지 확인하는 것이 목적이다. 실제 학습 성능을 검증하는 단계가 아니다.

### 학습이 포함된 실습

| 항목 | 테스트 기준 |
|---|---|
| 데이터셋 크기 | 2배치, 배치당 4개 샘플 (총 8개) |
| 에포크 | 1 |
| 원칙 | 원본 코드 구조를 변경하지 않고 크기만 축소 |

### API / LLM 사용 실습

- API 키가 필요한 경우 사용자에게 직접 요청한다
  - 메시지 예시: "실행을 위해 OpenAI API 키가 필요합니다. 키를 알려주시면 환경 변수에 설정하겠습니다."
- API 호출이 실제로 성공하는지 반드시 검증한다
- LLM 에이전트의 사용자 입력은 `input()` 함수를 사용한다. 임의의 문자열을 만들어 넣지 않는다

---

## TODO 셀 작성 규칙

`### Cell [TODO]`로 마킹된 셀에는 **힌트 블록**과 **정답 코드**를 함께 작성한다.

### TODO 셀 구조

```python
### Cell [TODO]
"""
### 문제: 옵티마이저를 Adam 대신 다른 것으로 교체하여 학습해 보세요.

아래 선택지 중 하나를 골라 옵티마이저를 정의하고, 동일한 학습 루프를 실행한 뒤
기존 Adam 결과와 비교해 보세요.

- SGD: momentum을 0.9로 설정하고, 학습률은 0.01로 시작
- AdamW: weight_decay를 0.01로 설정
- RMSprop: centered 옵션을 활성화하고 alpha를 0.99로 설정
"""
# [TODO-ANSWER]
optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9)
trainer.fit(model, optimizer, train_loader, epochs=10)
# [/TODO-ANSWER]
```

### 규칙

- docstring(`"""..."""`)에 힌트를 **글로만** 작성한다. 코드 스니펫을 힌트에 포함하지 않는다.
- 선택지가 있는 경우 불렛포인트로 나열한다.
- `# [TODO-ANSWER]` ~ `# [/TODO-ANSWER]` 블록 안에 정답 코드를 작성한다.
- 정답 코드는 실제로 실행 가능해야 한다 (run.py 실행 시 이 코드도 함께 검증됨).
- 하나의 `### Cell [TODO]`에는 반드시 docstring(힌트)과 정답 코드가 모두 있어야 한다.
- TODO에서 비교 실험을 요구하는 경우(예: "A vs B를 비교하세요"), 비교 대상을 생성하는 절차가 해당 노트북 안에 완결되어야 한다. 노트북 밖의 결과를 전제하지 않는다.

### 정답이 명확한 deterministic 문제 원칙 (필수)

TODO는 **정답이 한 가지로 모이는 deterministic한 문제**로 설계한다. open question("자유롭게 X해보세요", "원하는 프롬프트로 실험해보세요")은 금지한다.

- 비교 대상(프롬프트, 매개변수 값, 데이터)은 문제 본문에 직접 박아 넣는다.
- 학생이 채울 코드의 형태가 한 가지로 결정되어야 한다 (호출 인자, 출력 형식, 비교 로직).
- 비교 실험이라면 결과의 기대 패턴(예: "P1의 1등 토큰 확률이 P2보다 높을 것")까지 학생이 print하도록 지시한다.
- LLM 응답이 비결정적이어도 호출/출력/비교 코드 자체는 deterministic하게 만들 수 있다.
- `input()`을 사용해도 좋지만, 학생이 작성해야 할 코드의 형태는 입력값과 무관하게 한 가지로 정해져야 한다.

**금지 예시:** "원하는 프롬프트로 temperature 0.0과 1.0을 비교해 보세요."

**권장 예시:** "주어진 프롬프트 P1과 P2에 대해 `temperature=0.0`으로 각 3회 호출하여 응답을 출력하고, 같은 답이 반복되는지 한 줄로 판단해 print하세요."

### 변환 시 동작 (5단계 참고)

| 산출물 | TODO 셀 처리 |
|---|---|
| `<실습명>.ipynb` (학생본) | docstring → 마크다운 셀, 정답 코드 → 빈 코드 셀(`# 여기에 코드를 작성하세요`) |
| `<실습명>_full.ipynb` (강사본) | docstring → 마크다운 셀, 정답 코드 → 코드 셀 (정답 포함) |
| `<실습명>_answer.md` | TODO 번호 + 힌트 요약 + 정답 코드 블록 |

---

## skeleton 노트북 (run_todo_*.py)

plan.py에서 skeleton 목록이 기획된 경우, run.py와 동일한 규칙으로 `.biproducts/artifacts/run_todo_<이름>.py`를 작성한다.

### skeleton 작성 원칙

- skeleton 노트북은 메인 노트북과 동일한 구조를 따르되, 데이터셋과 관련 설정만 교체한다.
- skeleton의 모든 셀은 `### Cell [TODO]`일 수도 있고, 일부만 TODO일 수도 있다.
- skeleton 역시 run.py와 함께 실행하여 오류가 없는지 검증한다.

---

## 디버깅 절차

1. `.biproducts/artifacts/run.py`를 실행한다
2. 오류가 발생하면 원인을 분석하고 수정 후 재실행한다
3. 오류 없이 전체 실행이 완료될 때까지 반복한다
4. 완료되면 `.biproducts/runtime/execution-log.md`에 최종 실행 결과를 기록한다

### 실행 결과 기록

실행 결과는 터미널에 즉시 표시하지 않는다. 각 실행 시도마다 아래 형식으로 `.biproducts/runtime/execution-log.md`에 누적 기록하고, 디버깅 완료 후 사용자에게 이 파일을 검토 요청한다.

```markdown
## 실행 #N (YYYY-MM-DDTHH:MM:SSZ)

### 결과
성공 / 실패

### 출력 (stdout)
...

### 오류 (stderr)
...

### 수정 내용
(이번 시도에서 변경한 내용)
```

### 의존성 관리

실행 중 새 패키지를 설치하거나 특정 버전이 필요한 경우, 즉시 루트의 `requirements.txt`에 반영한다.

- pip 설치: `pip install torch==2.1.0` → `requirements.txt`에 `torch==2.1.0` 추가
- conda 설치: `conda install -c conda-forge <패키지>` → `requirements.txt`에 `<패키지>==<버전>` 추가
- `requirements.txt`가 없으면 새로 생성한다

---

## 절차

### 1. run.py 작성

`.biproducts/artifacts/plan.py`의 주석 구조를 유지하면서 실제 코드를 채워 넣는다.
사용자가 `.biproducts/artifacts/plan.py`에 추가한 pseudo code나 미완성 코드가 있으면 이를 우선 반영한다.
`### Cell [TODO]` 마킹이 있는 셀에는 위 "TODO 셀 작성 규칙"에 따라 힌트 블록과 정답 코드를 함께 작성한다.

### 2. skeleton 노트북 작성 (해당 시)

plan.py에 skeleton 목록이 있으면 `.biproducts/artifacts/run_todo_<이름>.py`를 각각 작성한다.

### 3. 실행 및 디버깅

run.py를 실행하고 오류가 없을 때까지 수정한다. skeleton 파일이 있으면 각각도 실행하여 검증한다.

### 4. 작업 중단

정상 실행이 확인되면 아래 메시지를 출력하고 반드시 작업을 멈춘다.

멈추기 전에 아래를 반드시 수행한다.

- `.biproducts/runtime/status.json`을 `step: 3`, `status: "needs_review"`로 갱신
- `changed_files`에 `.biproducts/artifacts/run.py`, `run_todo_*.py`(해당 시), 실행 중 생긴 보조 파일 반영
- `.biproducts/runtime/last-response.md`에 실행 결과와 검토 요청 기록
- `.biproducts/runtime/events.jsonl`에 `file_written`, `awaiting_user_review` 이벤트 추가
- `requirements.txt`가 갱신됐다면 `changed_files`에 포함

> `.biproducts/artifacts/run.py` 실행이 완료됐습니다.
> 실행 로그는 `.biproducts/runtime/execution-log.md`에서 확인할 수 있습니다.
> 코드와 출력 결과를 검토해 주세요.
> 수정이 필요한 부분을 알려주시면 반영한 뒤 다음 단계로 넘어가겠습니다.

### 5. 수정 반영

사용자의 수정 요청을 모두 반영하고 재실행해 검증한다.
사용자의 최종 승인이 있어야만 4단계로 진행한다. 승인 없이 넘어가지 않는다.

### 6. 다음 단계

`stages/stage-4-markdown.md`를 읽고 4단계를 시작한다.
