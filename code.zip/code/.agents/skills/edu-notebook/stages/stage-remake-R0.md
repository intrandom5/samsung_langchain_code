# 리메이크 R0: 노트북 분석 및 작업 범위 결정

## 목표

기존 `.ipynb` 노트북을 분석해 현재 상태를 파악하고, 사용자와 함께 무엇을 만들거나 보강할지 결정한다.

---

## 절차

### 1. 작업 공간 초기화

사용자가 지정한 경로에 `.biproducts/artifacts/`와 `.biproducts/runtime/` 디렉토리를 생성한다.

### 2. 노트북 분석

기존 `.ipynb` 파일을 읽고 아래 항목을 파악한다.

**마크다운 품질 확인**
- 각 `### Cell` 블록에 마크다운 셀(docstring)이 있는가
- 마크다운 내용이 비어 있거나 한 줄 이하로 부실한 셀이 몇 개인가

**산출물 존재 확인**
- 작업 공간 루트에 `requirements.txt`가 있는가
- 작업 공간 루트에 `README.md`가 있는가
- `_full.ipynb` (강사본)가 있는가

**라이브러리 목록 추출**
- 노트북의 코드 셀에서 `import` 문을 모두 수집한다
- 이를 바탕으로 `.biproducts/artifacts/base_instruction.md` 초안을 작성한다

base_instruction.md 초안 작성 시 채울 수 없는 항목(환경 이름, conda/venv 여부, 플랫폼 등)은 빈칸으로 남긴다.

### 3. 체크리스트 제시 후 중단

분석 결과를 요약하고 아래 형식으로 사용자에게 제시한다. 반드시 작업을 멈추고 사용자의 응답을 기다린다.

---

분석 결과 요약 예시:

```
[분석 결과]
- 마크다운 셀: 전체 14개 셀 중 6개가 비어 있거나 부실함
- requirements.txt: 없음
- README.md: 없음
- _full.ipynb (강사본): 없음

[base_instruction.md 초안을 .biproducts/artifacts/base_instruction.md에 작성했습니다]
환경 이름, conda/venv 여부 등 비어 있는 항목을 직접 채워주세요.

[이번 작업에서 진행할 항목을 선택해 주세요]
[ ] 마크다운 셀 보강 (설명이 부실한 셀을 교육용 수준으로 다듬음)
[ ] 새 섹션 추가 (노트북 중간에 새로운 내용을 삽입)
[ ] requirements.txt 생성
[ ] _full.ipynb (강사본) 생성
[ ] README.md 생성

base_instruction.md 보완이 완료되고 항목을 선택하셨으면 알려주세요.
```

---

멈추기 전에 아래를 반드시 수행한다.

- `.biproducts/runtime/status.json`을 `step: "R0"`, `status: "needs_review"`로 갱신
- `.biproducts/runtime/last-response.md`에 분석 요약과 체크리스트 기록
- `.biproducts/runtime/events.jsonl`에 `step_started`, `awaiting_user_review` 이벤트 추가

### 4. 다음 단계

사용자가 체크리스트를 확인하고 base_instruction.md를 보완했다고 알려오면 `stages/stage-remake-R1.md`를 읽고 진행한다.
