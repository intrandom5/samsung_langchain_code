# 6단계: 최종 README 작성

## 목표

최종 사용자에게 남길 `README.md`를 생성한다.
이 문서는 실습 개요, 실행 방법, 산출물 설명을 담고, 루트에 남는 최종 문서다.

---

## 핵심 원칙: 최종 사용자 문서만 남긴다

`README.md`에는 학습자나 검토자가 바로 이해해야 할 내용만 포함한다.
중간 산출물 설명이나 내부 작업 로그는 `.biproducts/` 아래에만 남기고, 루트 README에는 넣지 않는다.

---

## 문서 구조

```markdown
# <실습명>

## 실습 개요
- 주제:
- 사용 환경:
- 주요 라이브러리:

## 실행 방법
- 필요한 환경:
- 실행 순서:

## 산출물
- 학생본: `<실습명>.ipynb`
- 강사본: `<실습명>_full.ipynb`
- 정답 문서: `<실습명>_answer.md` (TODO가 있을 때만)
- 강의 노트: `lecture.md`
- 실행 의존성: `requirements.txt`

## 참고 사항
- 데이터 준비 방법
- 유의할 점
```

---

## 작성 지침

- 설명은 처음 접하는 사용자가 바로 실행할 수 있다는 기준으로 작성한다
- 내부 설계 파일(`base_instruction.md`, `plan.py`, `run.py`)의 상세 내용은 루트 README에 복사하지 않는다
- 이모티콘 사용 금지
- 마무리 정리 섹션 금지

---

## 파일 저장 위치

```
<작업공간>/README.md
```

---

## 위임

README 작성은 정해진 템플릿을 채우는 단순 작업이다. **Claude Code 환경인 경우** Haiku subagent에 위임할 수 있다. 위임 시 아래 파일을 컨텍스트로 전달한다.

- `.biproducts/artifacts/base_instruction.md`
- 완성된 노트북 파일 목록과 경로
- `requirements.txt` 내용

---

## 절차

### 1. 기존 산출물 검토

`.biproducts/artifacts/base_instruction.md`, `.biproducts/artifacts/run.py`, 완성된 노트북, `requirements.txt`를 읽고 최종 사용자 문서에 필요한 정보를 추린다.

### 2. README 구성

실습 개요, 실행 방법, 산출물, 참고 사항을 간결하게 정리한다.

### 3. lecture.md 복사

`.biproducts/artifacts/lecture.md`를 작업 공간 루트로 복사한다.

### 4. README 작성

위 문서 구조에 따라 `README.md`를 작성한다.

### 5. 상태 갱신 및 다음 단계 안내

완성된 `README.md`를 사용자에게 전달한다.

아래를 수행한다.

- `.biproducts/runtime/status.json`을 `step: 6`, `status: "completed"`로 갱신
- `changed_files`에 최종 산출물 목록 반영
- `.biproducts/runtime/last-response.md`에 최종 결과 요약 기록
- `.biproducts/runtime/events.jsonl`에 `step_completed` 이벤트 추가

### 6. 다음 단계

`stages/stage-7-zip.md`를 읽고 7단계를 시작한다.
