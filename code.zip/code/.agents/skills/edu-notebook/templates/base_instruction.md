# 실습 요구사항

1. 사용할 환경 (환경 도구 / 환경 이름 또는 경로):
   예) venv / ./my-env,  conda / langchain-env

2. 실습 주제:

3. 사용할 플랫폼:

3.1 사용할 데이터:
    아래 세 가지 유형 중 하나를 선택하고 관련 정보를 기재한다.

    [유형 A] 라이브러리/웹 자동 다운로드
      - 해당 라이브러리 또는 URL:
      예) sklearn.datasets.fetch_california_housing, torchvision CIFAR-10, HuggingFace datasets, seaborn, roboflow 등

    [유형 B] 사용자가 직접 제공 (로컬 파일)
      - 데이터 경로 (노트북 기준 상대 경로):
      예) ./data/images, ./data/train.csv

    [유형 C] Kaggle 대용량 데이터셋 (100MB 이상)
      - Kaggle 데이터셋 주소:
      예) https://www.kaggle.com/competitions/titanic

4. 레퍼런스 자료:

5. 참고해야 할 선행학습 자료:
