---
name: edu-notebook
description: >
  교육용 주피터 노트북을 단계별로 생성한다. 사용자의 요구사항 수집부터
  파이썬 스크립트 디버깅, 마크다운 셀 작성, 노트북 변환까지 다단계 워크플로를 따른다.
  사용자 검토와 승인이 필요한 단계마다 반드시 작업을 멈추고 응답을 기다린다.
---

# 교육용 주피터 노트북 생성 스킬

## 이 스킬의 목적

실습용 주피터 노트북을 체계적으로 제작한다. 사용자의 요구사항을 수집하고,
실습 흐름을 기획하고, 파이썬 스크립트로 검증한 뒤, 최종 노트북을 생성한다.

## 왜 파이썬 스크립트를 먼저 작성하는가

주피터 노트북은 셀 단위 실행 특성상 디버깅이 어렵다. 변수 상태가 셀 실행 순서에
의존하며 전체 흐름을 한 번에 검증하기 힘들다. 따라서 이 스킬에서는 파이썬 스크립트를
주피터 노트북의 대리(proxy)로 삼아 전체 코드를 선형으로 실행하고 디버깅한 뒤,
검증이 완료된 코드를 노트북으로 변환하는 방식을 채택한다.

---

## 실행 환경

이 스킬은 Claude Code, Cursor, Codex, OpenCode, Antigravity 등 여러 에이전트 환경에서 사용된다.

**Subagent 위임은 Claude Code, Codex 전용이다.** 각 단계에서 subagent 위임이 언급된 경우, 현재 환경이 Claude Code인지 먼저 확인한다.

| 환경 | Subagent 사용 | 처리 방식 |
|---|---|---|
| Claude Code, Codex | 가능 | subagent에 위임 |
| 그 외 (Cursor, Antigravity, OpenCode 등) | 불가 | 해당 단계의 폴백 절차를 직접 수행 |

Claude Code 여부는 `Agent` 도구 사용 가능 여부로 판단한다.

---

## 단계 요약 및 중단 지점

각 단계의 상세 지침은 `stages/` 디렉토리의 파일을 읽는다.

| 단계 | 파일 | 중단 시점 | 재개 조건 |
|---|---|---|---|
| 0 | (이 파일) | 없음 | 작업 공간 생성 후 바로 1단계로 |
| 1 | `stages/stage-1-requirements.md` | base_instruction.md 생성 직후 | 사용자가 작성 완료를 알림 |
| 1b | `stages/stage-1b-lecture.md` | lecture.md 생성 직후 | 사용자가 검토/수정 완료를 알림 |
| 2 | `stages/stage-2-planning.md` | plan.py 생성 직후 | 사용자가 검토/수정 완료를 알림 |
| 3 | `stages/stage-3-scripting.md` | run.py (+ run_todo_*.py) 실행 완료 직후 | 사용자가 검토/수정 완료를 알림 |
| 4 | `stages/stage-4-markdown.md` | 없음 | 작성 완료 후 바로 5단계로 |
| 5 | `stages/stage-5-notebook.md` | 없음 | 노트북 생성 완료 후 바로 6단계로 |
| 6 | `stages/stage-6-reference.md` | 문서 생성 완료 | 바로 7단계로 |
| 7 | `stages/stage-7-zip.md` | `<과정명>_elice.zip` 생성 완료 | 워크플로 종료 |

---

## 0단계: 작업 공간 설정 및 모드 결정

### 새로 만들기 vs 리메이크

스킬을 시작할 때 반드시 사용자에게 아래 둘 중 하나를 선택하게 한다.

- **새로 만들기**: 처음부터 노트북을 제작한다. 아래 작업 공간 구조를 생성한 뒤 `stages/stage-1-requirements.md`를 읽고 1단계를 시작한다.
- **리메이크**: 기존 `.ipynb` 노트북을 기준으로 빠진 산출물을 채우거나 내용을 보강한다. `stages/stage-remake-R0.md`를 읽고 리메이크 단계를 시작한다.

사용자가 이미 기존 노트북 경로를 제시했거나 "리메이크", "보강", "추가" 등의 표현을 사용한 경우 리메이크로 간주하되, 불확실하면 명시적으로 질문한다.

---

사용자가 새로 만들기를 선택한 경우, 작업 디렉토리를 지정하지 않았으면 질문하여 작업 공간을 설정한다.

작업 공간의 구조는 다음과 같다.

```
<작업공간>/
├── .biproducts/
│   └── artifacts/
│       ├── base_instruction.md   # 사용자 요구사항 (1단계)
│       ├── lecture.md            # 강의 노트 (1b단계)
│       ├── plan.py               # 실습 기획 스크립트 (2단계)
│       ├── run.py                # 실행/디버깅용 스크립트 (3단계)
│       └── run_todo_<이름>.py    # skeleton 노트북용 스크립트 (3단계, 필요 시)
│   └── runtime/
│       ├── status.json           # 현재 단계/상태/변경 파일 목록
│       ├── last-response.md      # 사용자에게 보여줄 최근 응답 요약
│       └── events.jsonl          # 단계 전환 및 주요 이벤트 로그
├── data/                         # 실습 데이터 (필요 시)
├── requirements.txt              # 최종 실행 의존성
├── <실습명>.ipynb                # 학생본 (TODO 포함)
├── <실습명>_full.ipynb           # 강사본 (정답 포함 완성본)
├── <실습명>_answer.md            # TODO 정답 모음
├── <실습명>_todo_<이름>.ipynb    # skeleton 노트북 (필요 시)
├── <실습명>_todo_<이름>_answer.md # skeleton 정답 (필요 시)
├── lecture.md                    # 강의 노트 (6단계에서 artifacts → 루트 복사)
└── README.md                     # 최종 사용자 안내 문서 (6단계)
```

작업 공간 생성 후 `stages/stage-1-requirements.md`를 읽고 1단계를 시작한다.

리메이크를 선택한 경우, 작업 공간 구조는 위와 동일하게 생성하되 `.biproducts/artifacts/` 안의 파일들은 분석 결과로 채운다.

---

## 명시적 상태 보고 규칙

이 스킬은 각 실습 폴더의 `.biproducts/runtime/` 아래에 상태를 기록한다.
상태 파일은 전역 위치가 아니라 반드시 현재 실습 작업공간 안에 있어야 한다.

### 상태 파일

- `status.json`
  - 현재 단계 번호
  - 현재 상태 (`in_progress`, `needs_review`, `completed`, `blocked`)
  - 최근 업데이트 시각
  - 최근 변경 파일 목록
  - 다음 사용자 액션
- `last-response.md`
  - 현재 단계에서 사용자에게 보여줄 최근 요약
  - 무엇을 생성/수정했는지
  - 무엇을 검토해달라는지
- `events.jsonl`
  - 단계 시작
  - 파일 생성/수정
  - 사용자 검토 대기
  - 단계 완료

### 상태 업데이트 원칙

- 각 단계를 시작할 때 `status.json`을 해당 단계의 `in_progress`로 갱신한다.
- 파일을 생성하거나 수정한 뒤에는 `changed_files`를 갱신한다.
- 사용자 검토나 승인 때문에 멈출 때는 반드시
  - `status.json`을 `needs_review`로 갱신하고
  - `last-response.md`를 갱신하고
  - `events.jsonl`에 이벤트를 1줄 추가한다.
- 전체 워크플로가 끝나면 `status.json`을 `completed`로 기록한다.

### `status.json` 예시

```json
{
  "workflow": "edu-notebook",
  "step": 2,
  "status": "needs_review",
  "updated_at": "2026-03-08T05:00:00Z",
  "changed_files": [
    ".biproducts/artifacts/plan.py"
  ],
  "next_action": "plan.py를 검토하고 수정이 끝나면 알려주세요."
}
```

### `events.jsonl` 예시

```jsonl
{"ts":"2026-03-08T04:58:00Z","type":"step_started","step":2}
{"ts":"2026-03-08T04:59:00Z","type":"file_written","path":".biproducts/artifacts/plan.py"}
{"ts":"2026-03-08T05:00:00Z","type":"awaiting_user_review","step":2}
```

---

## 전 단계 공통 금지 사항

- 반말 사용금지. 설명은 존댓말을 사용하며, 주석이나 불렛포인트 등 요약형 문맥에서는 체언 종결로 작성한다.
  - 체언 종결 예시: "데이터 로딩 및 전처리", "모델 정의", "손실 함수 계산", "결과 시각화"
  - 존댓말 예시: "아래 코드를 실행하면 모델이 학습됩니다."
  - 금지: "데이터를 로딩하고 전처리합니다" (불렛포인트에서), "모델 정의하기" (명사형 종결)
- 이모티콘 사용 금지 (코드, 주석, 마크다운 어디에도)
- 사용자 승인 없이 단계 건너뛰기 금지
- 최종 실습 노트북 파일에서는 LLM / 에이전트 실습에서 LLM이나 에이전트에게 입력값을 deterministic하게 입력하지 말고, input() 함수를 통해 사용자가 텍스트를 입력하도록 할 것
- run.py를 만드는 3단계에서 실습에 학습이 포함될 경우 전체 데이터셋으로 테스트 실행 금지. 극소수의 데이터(전체 학습/검증 데이터 중 8개만 사용, batch_size=4, len(batch)=2, epoch=1)
  - 다만, 최종 학습 노트북에서는 전체 데이터를 활용하도록
- 노트북의 마지막에 마크다운이나 print 함수를 사용하여 마무리 정리 섹션 작성 금지
- 무의미한 print 작성 금지 (예: `print("라이브러리 임포트 완료!")`)
