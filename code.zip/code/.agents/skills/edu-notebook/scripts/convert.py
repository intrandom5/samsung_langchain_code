"""run.py를 주피터 노트북(.ipynb)으로 변환하는 도구.

사용법:
    python convert.py <run.py 경로> <출력.ipynb 경로>
    python convert.py .biproducts/artifacts/run.py my_notebook.ipynb

세 가지 산출물을 생성한다:
    - <출력>.ipynb         : 학생본 (TODO 셀은 빈 코드 셀로 변환)
    - <출력>_full.ipynb    : 강사본 (정답 코드 포함)
    - <출력>_answer.md     : TODO 정답 모음 문서

TODO 셀이 없으면 학생본과 강사본이 동일하며, answer.md는 생성하지 않는다.

변환 전에 ipynb 호환성을 자동 검증한다.
위반 사항이 있으면 변환을 중단하고 오류를 출력한다.
"""
import nbformat
import re
import sys
from pathlib import Path


FORBIDDEN_PATTERNS = [
    (r'\b__file__\b', "__file__ 사용 불가 — Path('.') 또는 상대경로 사용"),
    (r'\bsys\.argv\b', "sys.argv 사용 불가 — 변수로 직접 선언"),
    (r'\bargparse\b', "argparse 사용 불가 — 변수로 직접 선언"),
    (r'^if\s+__name__\s*==\s*["\']__main__["\']\s*:', "if __name__ == '__main__' 가드 불필요"),
    (r'\bexit\s*\(', "exit() 사용 불가 — 노트북 커널이 종료됨"),
    (r'\bsys\.exit\s*\(', "sys.exit() 사용 불가 — 노트북 커널이 종료됨"),
    (r'^from\s+\.', "상대 import 불가 — 절대 import 사용"),
]


def validate(content: str) -> list[str]:
    """run.py의 ipynb 호환성을 검증한다."""
    violations = []
    in_docstring = False
    lines = content.split("\n")

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        # docstring 내부는 건너뛴다
        if '"""' in stripped or "'''" in stripped:
            count = stripped.count('"""') + stripped.count("'''")
            if count % 2 == 1:
                # 홀수 개: 토글 (열기 또는 닫기)
                in_docstring = not in_docstring
                continue
            # 짝수 개: 한 줄에 열고 닫기 (또는 닫고 열기) — 건너뜀
            continue
        if in_docstring:
            continue

        # 주석은 건너뛴다 (### Cell 제외)
        if stripped.startswith("#") and not stripped.startswith("### Cell"):
            continue

        for pattern, message in FORBIDDEN_PATTERNS:
            if re.search(pattern, stripped):
                violations.append(f"  L{i}: {message}")
                violations.append(f"       {stripped[:80]}")

    # docstring/코드 혼합 셀 검사 (TODO 셀은 예외: docstring + 정답 코드 허용)
    raw_cells = re.split(r"### Cell(?:\s+\[TODO\])?", content)
    header_markers = re.findall(r"### Cell(\s+\[TODO\])?", content)

    for idx, raw in enumerate(raw_cells):
        raw = raw.strip()
        if not raw:
            continue
        # TODO 셀은 docstring + 코드 혼합이 허용된다
        is_todo = idx > 0 and idx <= len(header_markers) and header_markers[idx - 1] is not None
        if is_todo:
            continue
        match = re.match(r'^("""|\'\'\')(.*?)\1', raw, flags=re.DOTALL)
        if match:
            remainder = raw[match.end():].strip()
            if remainder:
                violations.append(f"  Cell #{idx}: docstring과 코드가 혼합됨 — 별도 셀로 분리 필요")

    return violations


def parse(filepath: Path) -> list[dict]:
    """run.py를 파싱해 셀 목록을 반환한다.

    각 셀은 다음 키를 갖는다:
    - type: "markdown" | "code" | "todo"
    - source: 셀 내용
    - hint: TODO 셀의 경우 힌트 마크다운 (docstring 내용)
    - answer: TODO 셀의 경우 정답 코드
    """
    content = filepath.read_text(encoding="utf-8")
    # ### Cell 또는 ### Cell [TODO]로 분할
    parts = re.split(r"(### Cell(?:\s+\[TODO\])?)", content)
    cells = []

    i = 0
    while i < len(parts):
        part = parts[i].strip()

        if part == "### Cell":
            i += 1
            if i < len(parts):
                raw = parts[i].strip()
                if not raw:
                    i += 1
                    continue
                match = re.match(r'^("""|\'\'\')(.*?)\1', raw, flags=re.DOTALL)
                if match:
                    text = match.group(2).strip()
                    cells.append({"type": "markdown", "source": text})
                else:
                    cells.append({"type": "code", "source": raw})
            i += 1

        elif part == "### Cell [TODO]":
            i += 1
            if i < len(parts):
                raw = parts[i].strip()
                if not raw:
                    i += 1
                    continue

                # docstring에서 힌트 추출
                hint = ""
                answer = ""
                match = re.match(r'^("""|\'\'\')(.*?)\1', raw, flags=re.DOTALL)
                if match:
                    hint = match.group(2).strip()
                    remainder = raw[match.end():].strip()
                else:
                    remainder = raw

                # [TODO-ANSWER] ~ [/TODO-ANSWER] 블록에서 정답 추출
                answer_match = re.search(
                    r'#\s*\[TODO-ANSWER\]\s*\n(.*?)#\s*\[/TODO-ANSWER\]',
                    remainder,
                    flags=re.DOTALL,
                )
                if answer_match:
                    answer = answer_match.group(1).strip()

                cells.append({
                    "type": "todo",
                    "source": raw,
                    "hint": hint,
                    "answer": answer,
                })
            i += 1

        else:
            i += 1

    return cells


def build_notebook(cells: list[dict], mode: str = "student") -> nbformat.NotebookNode:
    """셀 목록으로 노트북 객체를 생성한다.

    mode:
      - "student": TODO 셀 → 힌트 마크다운 + 빈 코드 셀
      - "full": TODO 셀 → 힌트 마크다운 + 정답 코드 셀
    """
    nb = nbformat.v4.new_notebook()
    nb.metadata.kernelspec = {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3",
    }
    nb.metadata.language_info = {
        "name": "python",
        "version": "3.10.0",
    }

    for cell in cells:
        if cell["type"] == "markdown":
            nb.cells.append(nbformat.v4.new_markdown_cell(cell["source"]))

        elif cell["type"] == "code":
            nb.cells.append(nbformat.v4.new_code_cell(cell["source"]))

        elif cell["type"] == "todo":
            # 힌트 마크다운 셀
            if cell.get("hint"):
                nb.cells.append(nbformat.v4.new_markdown_cell(cell["hint"]))

            if mode == "student":
                nb.cells.append(nbformat.v4.new_code_cell(""))
            else:
                # 강사본: 정답 코드 포함
                answer = cell.get("answer", "")
                if answer:
                    nb.cells.append(nbformat.v4.new_code_cell(answer))
                else:
                    nb.cells.append(nbformat.v4.new_code_cell("# 정답 코드 없음"))

    return nb


def build_answer_md(cells: list[dict], title: str) -> str:
    """TODO 셀들의 정답을 모아 answer.md 내용을 생성한다."""
    todo_cells = [c for c in cells if c["type"] == "todo"]
    if not todo_cells:
        return ""

    lines = [f"# {title} - 정답 모음\n"]

    for idx, cell in enumerate(todo_cells, 1):
        hint = cell.get("hint", "")
        # 힌트의 첫 줄에서 제목 추출
        hint_title = ""
        for line in hint.split("\n"):
            line = line.strip().lstrip("#").strip()
            if line:
                hint_title = line
                break
        if not hint_title:
            hint_title = f"문제 {idx}"

        lines.append(f"\n## TODO {idx}: {hint_title}\n")
        answer = cell.get("answer", "")
        if answer:
            lines.append(f"```python\n{answer}\n```\n")
        else:
            lines.append("정답 코드가 없습니다.\n")

    return "\n".join(lines)


def convert(input_path: str, output_path: str) -> None:
    """run.py를 검증하고 노트북으로 변환한다.

    세 가지 산출물을 생성한다:
    - <output>.ipynb: 학생본
    - <output>_full.ipynb: 강사본
    - <output>_answer.md: 정답 문서 (TODO가 있을 때만)
    """
    src = Path(input_path)
    if not src.exists():
        print(f"파일을 찾을 수 없습니다: {src}")
        sys.exit(1)

    content = src.read_text(encoding="utf-8")

    # 1. 호환성 검증
    violations = validate(content)
    if violations:
        print("ipynb 호환성 위반 발견. 변환을 중단합니다.\n")
        for v in violations:
            print(v)
        print("\nrun.py를 수정한 뒤 다시 실행하세요.")
        sys.exit(1)

    # 2. 파싱
    cells = parse(src)
    if not cells:
        print("셀이 하나도 없습니다. ### Cell 구분자를 확인하세요.")
        sys.exit(1)

    dst = Path(output_path)
    dst.parent.mkdir(parents=True, exist_ok=True)
    stem = dst.stem
    parent = dst.parent

    has_todo = any(c["type"] == "todo" for c in cells)

    # 3. 학생본 생성
    nb_student = build_notebook(cells, mode="student")
    nbformat.validate(nb_student)
    with open(dst, "w", encoding="utf-8") as f:
        nbformat.write(nb_student, f)

    # 4. 강사본 생성
    full_path = parent / f"{stem}_full.ipynb"
    nb_full = build_notebook(cells, mode="full")
    nbformat.validate(nb_full)
    with open(full_path, "w", encoding="utf-8") as f:
        nbformat.write(nb_full, f)

    # 5. answer.md 생성 (TODO가 있을 때만)
    answer_path = parent / f"{stem}_answer.md"
    if has_todo:
        answer_content = build_answer_md(cells, stem)
        with open(answer_path, "w", encoding="utf-8") as f:
            f.write(answer_content)

    # 6. 요약
    md = sum(1 for c in cells if c["type"] == "markdown")
    code = sum(1 for c in cells if c["type"] == "code")
    todo = sum(1 for c in cells if c["type"] == "todo")
    total = md + code + todo

    print(f"변환 완료:")
    print(f"  학생본: {dst}")
    print(f"  강사본: {full_path}")
    if has_todo:
        print(f"  정답 문서: {answer_path}")
    print(f"  마크다운 셀: {md}개 | 코드 셀: {code}개 | TODO 셀: {todo}개 | 전체: {total}개")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("사용법: python convert.py <run.py 경로> <출력.ipynb 경로>")
        sys.exit(1)
    convert(sys.argv[1], sys.argv[2])
