# 노트북 → run.py 역변환 스크립트

`.ipynb` 파일을 `run.py` 형식으로 역변환한다.

---

## 변환 규칙

| 노트북 셀 타입 | run.py 변환 결과 |
|---|---|
| 마크다운 셀 | `### Cell` + `"""<내용>"""` |
| 코드 셀 | `### Cell` + 코드 그대로 |
| 빈 셀 | 건너뜀 |

---

## 변환 스크립트

```python
import json
import sys
from pathlib import Path


def convert(input_path: str, output_path: str) -> None:
    with open(input_path, encoding="utf-8") as f:
        nb = json.load(f)

    blocks = []

    for cell in nb["cells"]:
        source = "".join(cell["source"]).strip()
        if not source:
            continue

        if cell["cell_type"] == "markdown":
            blocks.append(f'### Cell\n"""\n{source}\n"""')
        elif cell["cell_type"] == "code":
            blocks.append(f"### Cell\n{source}")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n\n\n".join(blocks) + "\n")

    print(f"변환 완료: {output_path} ({len(blocks)}개 셀)")


if __name__ == "__main__":
    input_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else "run.py"
    convert(input_path, output_path)
```

---

## 실행 방법

```bash
python3 nb_to_runpy.py <입력노트북>.ipynb .biproducts/artifacts/run.py
```
