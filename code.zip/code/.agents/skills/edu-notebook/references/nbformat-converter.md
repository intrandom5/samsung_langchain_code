# nbformat 변환 도구

run.py → ipynb 변환은 `scripts/convert.py`를 직접 실행한다.

## 실행 방법

```bash
python <스킬경로>/scripts/convert.py <run.py 경로> <출력.ipynb 경로>
```

## 스크립트가 수행하는 것

1. ipynb 호환성 검증 (금지 패턴 + docstring/코드 혼합 검사)
2. `### Cell` 기준 분할 → 마크다운 셀 / 코드 셀
3. 커널 메타데이터 설정
4. `nbformat.validate()` 구조 검증
5. 셀 수 요약 출력

위반이 있으면 변환을 중단하고 라인 번호와 함께 오류를 출력한다.

## 파싱 규칙

- `### Cell` + docstring(`"""..."""`) → 마크다운 셀
- `### Cell` + 일반 코드 → 코드 셀
- 빈 블록 → 건너뛰기
